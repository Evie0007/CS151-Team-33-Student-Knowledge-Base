# Name of application: Students' Knowledgebase for Faculties

# Who did what:

# Version: 0.7
1. Sukirth Chanda: testing
2. Evie Ho: final testing, code & file clean up, updated Readme file 
3. Tanishq Tyagi: testing
3. Girum Yaye: testing

-----------------------------------------
Older Version:
# Version: 0.6
1. Sukirth Chanda: paticipating in CalHacks
2. Evie Ho: Updated Home Page, SearchStudentController, Database, , added edit-student-profile-page, EditStudentProfileController, testing, code & file clean up
3. Tanishq Tyagi: final testing
3. Girum Yaye: Updated view-student-profiles-page, ViewStudentProfilesController, StudentProfile, Database, added search-students-page


# Version: 0.5
1. Sukirth Chanda: StudentProfile.java
2. Evie Ho: ViewStudentProfileController, Home Page updates, testing, fix the Student Profile Page to fulfill the requirements, code & file clean up
3. Tanishq Tyagi: ViewStudentProfileController,DefineStudentProfileController, view-student-profile.fxml UI updates, files organize, testing
3. Girum Yaye: view-student-profile.fxml


# Version: 0.3
1. Sukirth Chanda: View Language Page, TableView, Testing
2. Evie Ho: testing, pom.xml, README, code and file clean up
3. Tanishq Tyagi:
3. Girum Yaye: Database management (SQLite), TableView, testing


# Version: 0.2
1. Sukirth Chanda: Added SQLite dependency to POM file, documentation
2. Evie Ho: Designed and implemented Home Page + Define Programming Languages Page (UI + navigation between pages), testing, code clean up
3. Tanishq Tyagi: Documentation, Testing
3. Girum Yaye: Testing


# Technical-Spec
1. Sukirth Chanda: Data Model
2. Evie Ho: Introduction, Design UML Sequence Diagram, Final Review
3. Tanishq Tyagi: 
3. Girum Yaye: Software Overview, Design UML Class Diagram


# Functional-Spec
1. Sukirth Chanda: Design mockup #2
2. Evie Ho: Introduction, Design mockup #1, update mockups #2 and use cases
3. Tanishq Tyagi: Use cases
3. Girum Yaye: Software overview, Design mockup #3



# Any other instruction that users need to know:



