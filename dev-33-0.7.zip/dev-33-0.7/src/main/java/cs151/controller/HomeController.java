package cs151.controller;

import cs151.util.FxUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class HomeController {

    @FXML
    private void onDefineLanguages(ActionEvent event) {
        FxUtil.switchScene(event, "define-languages-page.fxml", "Define Programming Languages");
    }

    @FXML
    private void onDefineStudentProfile(ActionEvent event) {
        FxUtil.switchScene(event, "define-student-profile-page.fxml", "Define Student Profile");
    }

    @FXML
    private void onViewStudentProfiles(ActionEvent event) {
        FxUtil.switchScene(event, "view-student-profiles-page.fxml", "View Student Profiles");
    }

    @FXML
    private void onSearchStudentProfiles(ActionEvent event) {
        FxUtil.switchScene(event, "search-students-page.fxml", "Search Student");
    }
}
