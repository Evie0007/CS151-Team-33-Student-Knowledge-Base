package cs151.application;

import cs151.db.Database;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Database.initialize();

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("home-page.fxml"));
        Scene scene = new Scene(loader.load(), 800, 800);
        stage.setTitle("Students' Knowledgebase");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
